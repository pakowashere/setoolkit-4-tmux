#!/usr/bin/env python

# FullScreen Attack SET Addon Module :: Example of Usage
# Author: d4rk0
# twitter: @d4rk0s

from src.webattack.fsattack.fsattacks import *


def mainFullScreenAttackLoadExample():

    # Load And Start
    x = fullScreenAttacks()
    # Checks config if set loads intro if not skips
    x.phishMenuMain()


# if __name__ == "__main__":
    # Run if executed

mainFullScreenAttackLoadExample()
